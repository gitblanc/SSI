
#include "ClipboardThread.h"

HANDLE h;

void ReadFromClipboard() {
	if (!OpenClipboard(NULL))
		return;

	h = GetClipboardData(CF_TEXT);

	// Can be stored into a file, send to a remote location....
	cout << (char*)h << endl;

	CloseClipboard();
}

void ClipboardThread(void* param)
{
	//cout << "In thread function" << endl;
	int i = 5; // Could be made a background permanent-running thread
	while (--i > 0) {
		ReadFromClipboard();
		Sleep(1000); // sleep for 1 second
	}
	//cout << "Thread function ends" << endl;
	_endthread();
}