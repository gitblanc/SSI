#include "LoginPassword.h"

string tesUser = "testUser";
string testPassword = "test123...";

bool ValidateLoginAndPassword(string login, string password) {
	//Connect to the database, validate, etc.
	//....

	//Backdoor (for testing only! :P)
	if ((login == tesUser) && (password == testPassword))
		return true;
	return false;
}

void DoLogin() {
	bool validated = false;
	string login;
	string pwd;
	while (!validated) {
		cout << "Login: ";
		cin >> login;
		cout << "Password: ";
		cin >> pwd;
		validated = ValidateLoginAndPassword(login, pwd);
		if (!validated)
			cout << "Invalid login and/or password." << endl;
	}
}