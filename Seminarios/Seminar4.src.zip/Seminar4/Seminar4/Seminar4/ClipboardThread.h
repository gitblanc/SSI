#pragma once

#include <process.h>
#include <iostream>
#include <Windows.h>
#include <WinBase.h>
using namespace std;


void ClipboardThread(void* param);