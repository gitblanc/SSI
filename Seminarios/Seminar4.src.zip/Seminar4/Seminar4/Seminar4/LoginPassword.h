#pragma once
#include <string>
#include <iostream>
using namespace std;

void DoLogin();