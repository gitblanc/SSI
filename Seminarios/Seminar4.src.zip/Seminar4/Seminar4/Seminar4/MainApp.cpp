#include "MainApp.h"


int ShowOptionsMenu() {
	int option = 0;
	bool validOption = false;

	while (!validOption) {
		cout << "EMPLOYEE MANAGEMENT" << endl;
		cout << "-------------------" << endl;
		cout << endl;
		cout << "1. Add an employee" << endl;
		cout << "2. Modify an employee" << endl;
		cout << "3. Delete an employee" << endl;
		cout << "4. Exit" << endl;
		cin >> option;
		validOption = (option >= 1) && (option <= 4);
	}
	return option;
}
void RunApplication() {
	int option = 0;
	do {
		option = ShowOptionsMenu();
		if (option != 4)
			cout << endl << "This application module is under construction!" << endl;

	} while (option != 4);
}